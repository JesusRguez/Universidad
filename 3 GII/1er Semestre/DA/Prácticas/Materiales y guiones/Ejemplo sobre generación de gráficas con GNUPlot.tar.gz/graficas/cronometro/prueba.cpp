#include <iostream>
#include "cronometro.h"
using namespace std;

int main()
{
  const long vueltas = 1000000000L;
  cout << "Medida del tiempo de control de un bucle de " << vueltas
       << " vueltas: \a" << flush;
  cronometro c;
  c.activar();
  for (long i = 0; i < vueltas; ++i)
    ;
  c.parar();
  cout << c.tiempo() << " s\a" << endl;
}
