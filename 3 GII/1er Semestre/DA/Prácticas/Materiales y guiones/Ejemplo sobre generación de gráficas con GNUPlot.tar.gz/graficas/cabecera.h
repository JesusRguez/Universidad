#ifndef _CABECERA_
#define _CABECERA_

inline double delta(size_t i,size_t j)
{
  return i==j;
}

#endif
