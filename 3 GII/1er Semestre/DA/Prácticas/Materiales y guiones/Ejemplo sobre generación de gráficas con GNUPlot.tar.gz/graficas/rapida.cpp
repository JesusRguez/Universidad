/* Ejemplo de uso de las utilidades MAKE y GNUPLOT. 
   
   IMPORTANTE: el siguiente codigo no representa la solucion 
               de ninguno de los ejercicios de las practicas
               y el esquema de medida temporal puede no ser
               correcto. Es tarea del alumno implementar la
               solucion y el esquema de medida temporal
               adecuado para cada ejercicio.

   Alberto Salguero (alberto.salguero@uca.es)
*/
#include <iostream>
#include <valarray>
#include "./cronometro/cronometro.h"
#include "./matriz/matriz.h"
#include "cabecera.h"


int main(){
	matriz a(40,40,delta);
	cronometro c;
	
	for(int i=0;i<=50;++i)
	{
		c.activar();
		for(int j=0;j<i;++j) { a * a; }
		c.parar();
		std::cout << i <<'\t'<< c.tiempo() <<std::endl;
	}
}
