#include <iostream>
#include "matriz.h"
using namespace std;

// Inserci�n de una matriz en un flujo de salida.

ostream& operator <<(ostream& fs, matriz& a)
{
  for (size_t i = 0; i < a.filas(); ++i) {
    for (size_t j = 0; j < a.columnas(); ++j)
      fs << a[i][j] << ' ';
    fs << endl;
  }
  return fs;
}

// Funci�n delta de Kronecker.

inline double delta(size_t i, size_t j)
{
  return i == j;
}

// Prueba.

int main()
{
  matriz a(3, 3);	  // Matriz nula de 3 x 3.
  matriz b(3, 3, 2.0);    // Matriz de 3 x 3 con todos sus elementos a 2. 
  matriz c(3, 3, delta);  // Matriz identidad de 3 x 3.
  a = c;
  cout << "A =\n" << a << endl;
  b += -a;
  cout << "B =\n" << b << endl;
  c *= c += c;
  cout << "C =\n" << c << endl;
  matriz d(a + b * c);
  cout << "A + B * C =\n" << d << endl;  
}
