// Clase para matrices de n�meros en coma flotante y doble precisi�n.

#ifndef MATRIZ_H_
#define MATRIZ_H_

#include <valarray>

class matriz {
public:				
  explicit matriz(size_t m = 1, size_t n = 1, double y = 0.0);
  matriz(size_t m, size_t n, double f(size_t i, size_t j));
  size_t filas() const;
  size_t columnas() const;
  std::valarray<double>& operator [](size_t i);
  const std::valarray<double>& operator [](size_t i) const;
  matriz& operator +=(const matriz& a);
  matriz& operator -=(const matriz& a);
  matriz& operator *=(const matriz& a);
  //inline double delta(size_t i,size_t j){return i==j};
  friend matriz operator -(const matriz& a);
private:
  size_t m, n;
  std::valarray<std::valarray<double> > x;
};

// Prototipos de operadores externos no amigos que trabajan con matrices.

const matriz& operator +(const matriz& a);
matriz operator +(const matriz& a, const matriz& b);
matriz operator -(const matriz& a, const matriz& b);
matriz operator *(const matriz& a, const matriz& b);

// Definiciones en l�nea.

#include "matriz-inline.h"

#endif
