/***************************************************************************//**
 * \file    main.c
 *
 * \brief   Funci�n main para la pr�ctica 10.
 */

#include <LPC407x_8x_177x_8x.h>
#include "glcd.h"
#include "adc_lpc40xx.h"
#include "timer_lpc40xx.h"
#include "termistor_ntc.h"

int main(void)
{
    /* C O M P L E T A R
     */
}


