#include <LPC407x_8x_177x_8x.h>
#include <string.h>
#include "generacion_audio.h"
#include "i2s_lpc40xx.h"
#include "tipos.h"
#include "error.h"
#include "uda1380.h"

#define  STREAM_DECODED_SIZE   (2*1152)

bool_t generando_audio = FALSE;

typedef struct {
  short int raw[STREAM_DECODED_SIZE];	/* 16 bit PCM output samples [ch][sample] */
  volatile  unsigned short wr_idx;
  volatile  unsigned short rd_idx;
}decoded_stream_t;

static decoded_stream_t     DecodedBuff;

#define IS_DFIFO_FULL()    ((DecodedBuff.wr_idx+1)%STREAM_DECODED_SIZE == DecodedBuff.rd_idx)
#define IS_DFIFO_EMPTY()   (DecodedBuff.wr_idx == DecodedBuff.rd_idx)

#define DFIFO_WRITE(S)     do {                                                                   \
                             DecodedBuff.raw[DecodedBuff.wr_idx] = S;                             \
                             DecodedBuff.wr_idx = ( (DecodedBuff.wr_idx+1)%STREAM_DECODED_SIZE ); \
                           }while(0)

#define DFIFO_READ(S)      do {                                                                   \
                             S = DecodedBuff.raw[DecodedBuff.rd_idx];                             \
                             DecodedBuff.rd_idx = ( (DecodedBuff.rd_idx+1)%STREAM_DECODED_SIZE ); \
                           }while(0)

#define FIFO_LEN()        ( DecodedBuff.wr_idx >= DecodedBuff.rd_idx ? \
                            DecodedBuff.wr_idx - DecodedBuff.rd_idx  : \
                            DecodedBuff.wr_idx + (STREAM_DECODED_SIZE - DecodedBuff.rd_idx) )

/***************************************************************************//**
 *
 */
void generacion_audio_habilitar(void)
{
    NVIC_ClearPendingIRQ(I2S_IRQn);
    NVIC_SetPriority(I2S_IRQn, 0);
    NVIC_EnableIRQ(I2S_IRQn);
    generando_audio = TRUE;
}

/***************************************************************************//**
 *
 */
void generacion_audio_deshabilitar(void)
{
    NVIC_DisableIRQ(I2S_IRQn);
    generando_audio = FALSE;
}

/***************************************************************************//**
 *
 */
void generacion_audio_esperar_fin_fragmento(void)
{
    generacion_audio_deshabilitar();
    //while (!IS_DFIFO_EMPTY());
}

/***************************************************************************//**
 *
 */
void generacion_audio_encolar_bloque_muestras(int32_t *ptr_muestras_izquierda,
                                              int32_t *ptr_muestras_derecha,
                                              uint16_t longitud,
                                              uint16_t numero_canales)
{
    uint16_t i;
    
    /* libmad genera muestras de 24 bits �tiles en los 24 bits m�s significativos
     * de datos de 32 bits. Aqu� se convierten a 16 bits antes de enviarlos al
     * buffer de muestras.
     */
          
    if (numero_canales == 1)
    {
        for (i = 0; i < longitud; i++)
        {
            while (IS_DFIFO_FULL());
            DFIFO_WRITE((int16_t)((*ptr_muestras_izquierda) >> 16));
            DFIFO_WRITE((int16_t)((*ptr_muestras_izquierda) >> 16));
            ptr_muestras_izquierda++;
        }
    }
    else if (numero_canales == 2)
    {
        for (i = 0; i < longitud; i++)
        {
            while (IS_DFIFO_FULL());
            DFIFO_WRITE((int16_t)((*ptr_muestras_izquierda) >> 16));
            ptr_muestras_izquierda++;
            DFIFO_WRITE((int16_t)((*ptr_muestras_derecha) >> 16));
            ptr_muestras_derecha++;
        }
    }
    else
    {
        ERROR("Numero de canales incorrecto.");
    }

    if (!generando_audio) generacion_audio_habilitar();
}

/***************************************************************************//**
 *
 */
void generacion_audio_ajustar_tasa_muestreo(uint32_t sample_rate)
{
    /* ESTA FUNCI�N PUEDE DEJARSE VAC�A SI TODOS LOS FICHEROS MP3 QUE VAMOS
     * A REPRODUCIR TIENEN UNA FRECUENCIA DE MUESTREO DE 44100 Hz. DE MOMENTO
     * PODEMOS DEJARLA SIN COMPLETAR.
     */
}

/***************************************************************************//**
 *
 */
void generacion_audio_inicializar(void)
{    
    DecodedBuff.wr_idx = DecodedBuff.rd_idx = 0;
    generando_audio = FALSE;

    //i2s_inicializar();
    uda1380_inicializar();
    generacion_audio_deshabilitar();
    
    __enable_irq();
}

/***************************************************************************//**
 * \brief   Funci�n manejadora de interrupci�n de las interrupciones del
 *          interfaz I2S.
 *
 *          En esta aplicaci�n, el interfaz I2S generar� interrupci�n siempre
 *          que el nivel de ocupaci�n de la FIFO de transmisi�n sea menor o
 *          igual a 4 (la mitad de su capacidad de 8 o menos).
 *
 *          La funci�n manejadora de interrupci�n sacar� del buffer de salida
 *          dos muestras mediante la macro DFIFO_READ, una para el canal
 *          izquierdo y otra para el canal derecho. Si la macro IS_DFIFO_EMPTY
 *          indica que el buffer de salida est� vac�o, dar valor 0 a ambas
 *          muestras.
 *
 *          NOTA: las macros DFIFO_READ y IS_DFIFO_EMPTY no se refieren a la
 *                FIFO de transmisi�n del I2S sino a la FIFO o buffer en la
 *                que el decodificador coloca las muestras de audio generados.
 *                En esta funci�n, recogemos las muestras de esta FIFO, las
 *                combinamos y las enviamos a la FIFO de transmisi�n del I2S.
 *
 *          Las dos muestras de 16 bits deben ser combinadas en un �nico dato de
 *          32 bits que es el que se enviar� a la FIFO de transmisi�n del I2S.
 *          La muestra del canal izquierdo debe colocarse en los 16 bits m�s
 *          significativos del dato de 32 bits y la muestra del canal derecho en
 *          los 16 menos significativos.
 *
 *          Una vez que hemos combinado las dos muestras en un dato de 32 bits
 *          escribimos �ste en la FIFO de transmisi�n del interfaz I2S y salimos.
 *
 *          PRECAUCI�N: las muestras de audio son n�meros de 16 con signo. Para
 *                      combinar las dos muestras izquieda/derecha en un �nico
 *                      dato de 32 bis ser� necesario realizar desplazamientos
 *                      y operaciones l�gicas. Seg�n escribamos la expresi�n
 *                      o expresiones para llevar a cabo estas operaciones puede
 *                      ser que estemos haciendo que el compilador promocione
 *                      datos con signo de 16 bits a datos con signo de 32 bits
 *                      lo que implica extender el bit de signo a los 16 bits
 *                      m�s significativos. Para evitar que esto cree problemas
 *                      a la hora de combinar las muestras (t�picamente con OR),
 *                      moldear el tipo de las dos muestras a uint32_t.
 */
void I2S_IRQHandler(void)
{
    int16_t muestra_izquierda;
    int16_t muestra_derecha;
        
    if (!IS_DFIFO_EMPTY())
    {
        DFIFO_READ(muestra_izquierda);
    }
    else
    {
        muestra_izquierda = 0;  
    }
    
    if (!IS_DFIFO_EMPTY())
    {
        DFIFO_READ(muestra_derecha);
    }
    else
    {
        muestra_derecha = 0;  
    }
   
    LPC_I2S->TXFIFO = ((uint32_t)muestra_izquierda << 16) |
                      ((uint32_t)muestra_derecha & 0xFFFF);
}
