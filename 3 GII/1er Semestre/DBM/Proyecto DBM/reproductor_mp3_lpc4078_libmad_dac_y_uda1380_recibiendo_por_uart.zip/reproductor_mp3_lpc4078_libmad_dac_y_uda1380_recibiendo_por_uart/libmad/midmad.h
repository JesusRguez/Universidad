#ifndef REPRODUCTOR_MP3_H
#define REPRODUCTOR_MP3_H

#include "ff.h"
#include "tipos.h"

int32_t reproducir_mp3(FIL *file);     
     
#endif
