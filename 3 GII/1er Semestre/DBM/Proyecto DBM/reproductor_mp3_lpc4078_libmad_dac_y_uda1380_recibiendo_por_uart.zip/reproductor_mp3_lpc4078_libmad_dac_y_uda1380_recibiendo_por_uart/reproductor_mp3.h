#ifndef REPRODUCTOR_MP3_H
#define REPRODUCTOR_MP3_H

#include "tipos.h"

int32_t reproducir_mp3(void);     
     
#endif
