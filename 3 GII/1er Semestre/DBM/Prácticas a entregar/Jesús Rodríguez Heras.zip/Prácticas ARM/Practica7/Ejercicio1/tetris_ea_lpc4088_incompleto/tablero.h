/*-------------------------------------------------------------------------*//**
 *
 */

#ifndef TABLERO_H
#define TABLERO_H

#include "error.h"

typedef struct
{
    int8_t cubeta[17][10];
} tablero_t;

#endif  /* TABLERO_H */
