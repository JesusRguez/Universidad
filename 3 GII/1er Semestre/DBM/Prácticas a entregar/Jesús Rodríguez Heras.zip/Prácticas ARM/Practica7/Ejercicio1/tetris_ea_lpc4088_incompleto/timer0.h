/*-------------------------------------------------------------------------*//**
 *
 */

#ifndef TIMER0_H
#define TIMER0_H

void timer0_inicializar(void);
void TIMER0_IRQHandler(void);

#endif  /* TIMER0_H */
