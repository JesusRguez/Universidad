/***************************************************************************//**
 * \file    main.c
 *
 * \brief   Funci�n main para la pr�ctica sobre los timers.
 */

#include <LPC407x_8x_177x_8x.h>
#include <stdio.h>
#include <stdlib.h>
#include "gpio_lpc40xx.h"
#include "timer_lpc40xx.h"
#include "glcd.h"
#include "joystick.h"
#include "leds.h"

/*******************************************************************************
 * Funci�n main para el ejericio 1.
 */
int main(void)
{
    uint32_t horas = 0, minutos = 0, segundos = 0;
    
    /* Inicializar la pantalla LCD.
     */
    glcd_inicializar();

    /* Inicializar el timer 0.
     */

    /* C O M P L E T A R
     */
    
    while (TRUE)
    {
        /* Imprimir el cronometro en la coordenada (0, 0) de la pantalla.
         */
        
        /* C O M P L E T A R
         */
        
        /* Realizar un retardo de 1 segundo.
         */
        
        /* C O M P L E T A R
         */

        
        /* Actualizar las variables segundos, minutos y horas.
         */
        
        /* C O M P L E T A R
         */
    }
}

/*******************************************************************************
 * Funci�n main para el ejericio 2.
 */
//int main(void)
//{
//    uint32_t horas = 0, minutos = 0, segundos = 0;
//    
//    /* Inicializar la pantalla LCD.
//     */
//    glcd_inicializar();

//    /* Inicializar el timer 0.
//     */
//    
//    /* C O M P L E T A R
//     */
// 
//    /* Configurar el timer 0 para que realice autom�ticamente ciclos de
//     * un segundo de duraci�n (funci�n timer_iniciar_ciclos_ms).
//     */
//    
//    /* C O M P L E T A R
//     */
//  
//    while (TRUE)
//    {
//        /* Imprimir el cronometro en la coordenada (0, 0) de la pantalla.
//         */
//        
//        /* C O M P L E T A R
//         */

//        /* Esperar a que finalice el ciclo de un segundo actual
//         * (funci�n timer_esperar_fin_ciclo).
//         */
//        
//        /* C O M P L E T A R
//         */

//        /* Actualizar las variables segundos, minutos y horas.
//         */
//        
//        /* C O M P L E T A R
//         */
//    }
//}

/*******************************************************************************
 * Funci�n main para el ejericio 3.
 */
//int main(void)
//{
//    uint32_t tiempo_aletorio;
//    uint32_t tiempo_reaccion;

//    /* Inicializar la pantalla LCD.
//     */    
//    glcd_inicializar();

//    /* Inicializar el timer 0.
//     */
//    
//    /* C O M P L E T A R
//     */
//    
//    while (TRUE)
//    {
//        /* Borrar la pantalla rellen�ndola de color negro.
//         */
//        
//        /* C O M P L E T A R
//         */
//   
//        /* Imprimir "Pulsa abajo para comenzar" en el LCD.
//         */
//        
//        /* C O M P L E T A R
//         */

//        /* Esperar hasta que el usuario pulse el joystick hacia abajo.
//         */
//        
//        /* C O M P L E T A R
//         */

//        /* Borrar la pantalla rellen�ndola de color negro.
//         */
//        
//        /* C O M P L E T A R
//         */

//        /* Imprimir "�Preparado!" en el LCD.
//         */
//         
//        /* C O M P L E T A R
//         */
//         
//        /* Generar un n�mero aleatorio entre 1000 y 5000.
//         */
//         
//        /* C O M P L E T A R
//         */
//        
//        /* Realizar un retardo de un n�mero de milisegundos igual al n�mero
//         * aleatorio generado.
//         */  
//         
//        /* C O M P L E T A R
//         */
//        
//        /* Borrar la pantalla rellen�ndola de color rojo.
//         */
//         
//        /* C O M P L E T A R
//         */
//     
//        /* Hacer que el timer 0 empiece a contar el transcurso del tiempo en
//         * unidades de milisegundos.
//         */
//         
//        /* C O M P L E T A R
//         */

//        /* Esperar a que usuario pulse el joystick hacia el centro.
//         */
//         
//        /* C O M P L E T A R
//         */

//        /* Leer el valor del registro contador del timer 0.
//         * El valor obtenido es el tiempo en milisegundos entre el momento en
//         * que la pantalla cambia a color rojo y el instante en el que el usuario
//         * pulsa el joystick hacia el centro = tiempo de reacci�n.
//         */
//         
//        /* C O M P L E T A R
//         */
//  
//        /* Imprimir en la pantalla el tiempo de reacci�n.
//         */
//         
//        /* C O M P L E T A R
//         */
//           
//        /* Hacer un retardo de 5 segundos para que el usuario tenga tiempo de leer
//         * su tiempo de reacci�n antes de empezar otro test.
//         */
//         
//        /* C O M P L E T A R
//         */
//    }    
//}
