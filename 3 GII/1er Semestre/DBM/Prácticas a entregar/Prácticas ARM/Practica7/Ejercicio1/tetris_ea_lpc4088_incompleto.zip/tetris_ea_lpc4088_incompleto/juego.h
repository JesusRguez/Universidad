/***************************************************************************//**
 */

#ifndef JUEGO_H
#define JUEGO_H

#define JUEGO_TERMINADO 1
#define JUEGO_PAUSADO   2

#define JUEGO_NUEVO     1
#define JUEGO_CONTINUAR 2

void juego(void);

#endif  /* JUEGO_H */
