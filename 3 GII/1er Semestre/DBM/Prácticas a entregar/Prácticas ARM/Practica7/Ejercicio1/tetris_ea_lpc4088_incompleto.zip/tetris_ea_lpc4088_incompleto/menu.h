/***************************************************************************//**
 */

#ifndef MENU_H
#define MENU_H

#include "tipos.h"

int32_t menu(void);

#endif  /* MENU_H */
