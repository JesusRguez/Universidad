/***************************************************************************//**
 */

#ifndef BLOQUE_H
#define BLOQUE_H

#include "tipos.h"

#define BLOQUE_TAMANO 15

void bloque_pintar(int32_t x, int32_t y, int16_t color);

#endif  /* BLOQUE_H */
