#include "qdbmp.h"
#include <stdio.h>
#include <time.h>

int sse_seleccionar_rgb_64(unsigned char *ptr_imagen,
                           int ancho,
                           int alto,
                           unsigned char seleccion_rgb);

int main(int argc, char* argv[])
{
    BMP*    bmp;
    unsigned int ancho, alto;

    /* Leer la imagen original.
     */

    bmp = BMP_ReadFile("imagen_rgb.bmp");
    BMP_CHECK_ERROR(stdout, -1);

    /* Obtener el ancho y el alto.
     */

    ancho = BMP_GetWidth(bmp);
    alto = BMP_GetHeight(bmp);

    /* Seleccionar los canales rojo y azul.
     */

    sse_seleccionar_rgb_64(bmp->Data, ancho, alto, 4);

    /* Escribir en disco la imagen resultante.
     */

    BMP_WriteFile(bmp, "imagen_modificada.bmp");
    BMP_CHECK_ERROR(stdout, -2);

    BMP_Free(bmp);

	return 0;
}
