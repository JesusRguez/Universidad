package aceptador;

import java.net.*;
import java.io.*;
  public class AceptadorConexion {
   public static void main(String[] args) {
       try {
          int numPuerto = 5000;
          String mensaje = "Soy el que acepta";
          // instancia un socket para aceptar la conexi�n
          ServerSocket socketConexion = new ServerSocket(numPuerto);
  /**/    System.out.println("preparado para aceptar una conexi�n");
          // espera una petici�n de conexi�n, instante en el cual
          // se crea un socket de datos
          MiSocketStream socketDatos =
            new MiSocketStream(socketConexion.accept());
  /**/    System.out.println("conexi�n aceptada");
          socketDatos.enviaMensaje(mensaje);

  /**/    System.out.println("mensaje enviado");
          socketDatos.close( );
  /**/    System.out.println("socket de datos cerrado");
          socketConexion.close( );
  /**/    System.out.println("socket de conexi�n cerrado");
        } // fin de try
        catch (Exception ex) {
          ex.printStackTrace( );
        } // fin de catch
    } // fin de main
  } // fin de class


