@javax.xml.bind.annotation.XmlSchema(namespace = "http://clases/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package clases;
