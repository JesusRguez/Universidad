@javax.xml.bind.annotation.XmlSchema(namespace = "http://clases/")
package clases;
