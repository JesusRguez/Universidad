Building Instructions

You need the following plugins for nsis to compile:

- InstDrv http://nsis.sourceforge.net/InstDrv_plug-in,
- ExecDos http://nsis.sourceforge.net/ExecDos_plug-in and 
- NewAdvSplash http://nsis.sourceforge.net/NewAdvSplash_plug-in for this Code
- UserMgr http://nsis.sourceforge.net/UserMgr_plug-in
- FindProcDLL http://nsis.sourceforge.net/FindProcDLL_plug-in

Build exe with nsis compiler and copy the binary to ../../