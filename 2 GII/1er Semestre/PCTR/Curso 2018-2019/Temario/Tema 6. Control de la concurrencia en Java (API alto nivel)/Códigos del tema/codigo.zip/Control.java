/**Ejemplo de Hilo hijo controlado por hilo padres
 * Muestra la creacion y ejecuci�n concurrente de varios hilos
 * @author Antonio Tomeu
 */
 
import java.io.*; 
public class Control extends Thread
{
	//No se declara un constructor explicito.Se usara el disponible por defecto
	
	public void run()
	{
		for(;;)
		  System.out.println("Trabajando");
	}
	
	
	public static void main(String[] args)
	  throws IOException
	{
		int c;
		
		Control Hilo = new Control(); //usando el constructor implicito
		Hilo.start();
		//un poquito de interfoliacion
		for(int i=1; i<=100; i++)
		  System.out.println("Hola soy el padre");
		//Ahora el hilo padre bloquea al hijo.
		Hilo.suspend();
		System.out.println("Hijo suspendido");
		//Ahora reactivamos al hijo, que pasa a listo.
		System.out.println("Pulsa Ctrl-Z para despertar al hijo");
		do {
			c=System.in.read();
		   }
		 while(c != -1);  
		Hilo.resume();
		//un poquito de interfoliacion otra vez.
		for(int i=1; i<=100; i++)
		  System.out.println("Hola soy el padre");
		//Ahora destruimos al hijo. Esto no debe hacerse NUNCA
		Hilo.stop();
		
	}	  
 	
}
 