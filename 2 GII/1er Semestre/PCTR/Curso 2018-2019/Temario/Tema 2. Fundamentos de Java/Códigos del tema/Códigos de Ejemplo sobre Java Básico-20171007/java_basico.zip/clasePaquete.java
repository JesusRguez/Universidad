/**
 * @(#)clasePaquete.java
 * @author Antonio Tomeu
 * @version 1.00 2011/10/12
 */

package mipaquete;
public class clasePaquete {

    public clasePaquete() { new clasePaquete_2();}


}