/**
 * @(#)EjemploScanner.java
 * @author Antonio Tomeu
 * @version 1.00 2011/10/5
 * Programa chorra que calcula el volumen de un cilindro
 */

import java.util.Scanner;

public class EjemploScanner {
  
    public static void main(String[] args) {
        final double Pi = 3.141592;
        double       r;
        double       h;
        
        Scanner Tec = new Scanner(System.in);
        
        System.out.println ("Introducir valores de radio y altura:");
        System.out.println ("r=");
        r = Tec.nextDouble(); 
        System.out.println ("h=");       
        h = Tec.nextDouble(); 
        System.out.println("Volumnen del cilindro es: "+Pi*r*r*h);
    }
}
