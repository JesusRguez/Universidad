/**
 * @(#)clasePaquete_2.java
 * @author AT
 * @version 1.00 2011/10/12
 */

package mipaquete;
public class clasePaquete_2 {

    public clasePaquete_2() {}


}