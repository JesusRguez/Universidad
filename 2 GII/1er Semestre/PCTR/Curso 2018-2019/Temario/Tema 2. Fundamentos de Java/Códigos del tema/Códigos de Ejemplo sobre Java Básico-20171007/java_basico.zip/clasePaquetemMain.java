/**
 * @(#)clasePaquetemMain.java
 *
 *
 * @author AT
 * @version 1.00 2011/10/12
 */

package mipaquete;
public class clasePaquetemMain {

    public static void main(String[] args) {
       clasePaquete   A = new clasePaquete();
       clasePaquete_2 B = new clasePaquete_2();
       System.out.println(A.toString());
       System.out.println(B.toString());
       System.out.println("me ejecute...");
    }
}
