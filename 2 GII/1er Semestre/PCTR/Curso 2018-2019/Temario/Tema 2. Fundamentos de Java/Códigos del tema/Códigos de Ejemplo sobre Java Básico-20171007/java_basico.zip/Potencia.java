//Antonio J. Tomeu
//Dpto. Lenguajes y Sistemas Inform�ticos
//�rea de CC. de la Computaci�n e I.A.
//Fichero Fibonacci.java
//Ilustra el uso de la estructura if...

class Potencia
{
  public static int potencia (int x, int y)
  { int i;
    int p = 1;
    
    if (y==0) return 1;
    else for (i=1; i<=y; i++)
          {p = p*x;}
    return p;      
  }
  
  public static void main (String [] args)
  {
    int Base = 2;
    int Exponente = 4;
    System.out.println (Base+" elevado a "+Exponente+" = "+potencia (Base, Exponente));
  }
}