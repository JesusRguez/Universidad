class Media
{
  public static void main (String [] args)
  {
    int i=11, j=20;
    double a=(i+j)/2.0;
    System.out.println ("La media es "+a);
  }
}