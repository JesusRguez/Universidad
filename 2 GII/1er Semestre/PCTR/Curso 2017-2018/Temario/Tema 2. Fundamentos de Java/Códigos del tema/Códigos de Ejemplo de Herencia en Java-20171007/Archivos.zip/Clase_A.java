public class Clase_A
{
	Clase_A (int x)
	{
		valor =x;
	}
	
	//calcula una funcion de una variable
	int Resultado ()
	{
		return valor*valor-(valor*2)+3;
	}
	
	protected int valor;
}