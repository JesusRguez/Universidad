public class Usa_Clases_A_B
{
	public static void main (String[] args)
	{
		Clase_A funcion1 = new Clase_A(2);
		Clase_B funcion2 = new Clase_B (2,2);
		System.out.println (funcion1.Resultado());
		System.out.println (funcion2.Resultado());
	}
}