/**
 * @(#)Superclase.java
 *
 *
 * @author AT
 * @version 1.00 2011/10/27
 */


public class Superclase {
  private int i;
  public Superclase(int dato) {i=dato;}
  public void accion()
 {
  for(int cont=1;cont<i; cont++)
    {System.out.println("Superclase escribiendo...");}
 }
 public void hola()
 {System.out.println("hola");}
}