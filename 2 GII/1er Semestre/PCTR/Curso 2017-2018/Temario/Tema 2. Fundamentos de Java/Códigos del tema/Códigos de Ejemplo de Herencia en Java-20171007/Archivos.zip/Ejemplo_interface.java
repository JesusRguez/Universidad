public interface Ejemplo_interface
{
	int operacion_binaria (int a, int b);
	int operacion_monaria (int a);
}	