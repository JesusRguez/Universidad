/**
 * @(#)UsaSuperySub.java
 *
 *
 * @author  AT
 * @version 1.00 2011/10/27
 */

public class UsaSuperySub {

  public static void main(String[] args)
  {
    Superclase A = new Superclase(10);
    Subclase   B = new Subclase();
    A.accion(); //superclase usa metodo original
    B.accion(3,4); //subclase usa metodo sobreescrito
    A.hola();
    B.hola(); //y esto, �qu� significa?
  }
}