public class Imp_Interface_3
  implements Ejemplo_interface
{
	public int operacion_binaria (int a, int b)
	{
		System.out.println("Hola, como estas...");
		return 25;
	}	
	
	public int operacion_monaria (int a)
	{
		return a*a*a;
	}	
}  