/**
 * @(#)Subclase.java
 *
 *
 * @author AT
 * @version 1.00 2011/10/27
 */


import java.util.*;
public class Subclase
  extends Superclase //hereda de superclase
{
   public Subclase() {super(3);}
  //sobreescribe el metodo accion, con otro compartamiento
  public void accion(double a, double b)
 {
  System.out.println("La hipotenusa es "+Math.sqrt(Math.pow(a,2)+Math.pow(b,2)));
 }
}