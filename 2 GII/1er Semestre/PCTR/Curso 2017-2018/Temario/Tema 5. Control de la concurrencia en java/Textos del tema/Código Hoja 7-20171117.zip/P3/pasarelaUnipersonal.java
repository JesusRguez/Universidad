/* EJEMPLO DE CONTROL DE UNA PASARELA UNIPERSONAL
 *@author A.T.
 *@date 11/20/2014
*/

import java.util.Scanner;
public class pasarelaUnipersonal extends Thread{
  public static Object Pasarela = new Object(); //recurso compartido
  
  public pasarelaUnipersonal(){this.start();}
  
  public void run(){
    for(;;){	  
      synchronized(Pasarela){
        System.out.println("Persona en pasarela...");	    
      }	    
      System.out.println("Persona saliendo de pasarela...");
    }//for  
  }//run
  
  public static void main(String[]args){
    pasarelaUnipersonal h = new pasarelaUnipersonal();
    pasarelaUnipersonal q = new pasarelaUnipersonal();
    try{
    	h.join(); q.join();
    }catch(InterruptedException e){}
  }
}
