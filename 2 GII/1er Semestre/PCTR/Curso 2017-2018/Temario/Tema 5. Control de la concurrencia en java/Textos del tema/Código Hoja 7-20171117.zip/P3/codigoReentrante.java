/* EJEMPLO DE CODIGO SINCRONIZADO REENTRANTE RECURSIVO
 *@author A.T.
 *@date 11/20/2014
*/

import java.util.Scanner;
public class codigoReentrante extends Thread{
  public static int vShared = 0; //recurso compartido
  public static int nRec = 1000; //profundidad de la recursion
  
  public  codigoReentrante(){this.start();}
  
  public void inc(){
    if(nRec>0){
      nRec--;
      synchronized(this){vShared++;} //reentrancia recursiva sobre re el cerrojo
      inc();
    }  	  
  }
  
  public void run(){
    inc();
  }
  public static void main(String[]args){
    codigoReentrante h = new codigoReentrante();
    try{h.join();}catch(InterruptedException e){}
    System.out.println(vShared);
  }
}
