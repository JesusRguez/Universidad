/* MEDIDA DEL TIEMPO QUE TOMAN LOS BLOQUEOS SINCRONIZADOS
 *@author A.T.
 *@date 11/11/2014
*/
import java.util.Scanner;
public class retardoMutex extends Thread{
  public static int vShared = 0;
  public        int tipoHilo;
  public static int nIter;
  public  retardoMutex(int tipoHilo){
    this.tipoHilo = tipoHilo;
  }
  public void run(){
    switch(tipoHilo){
      case 0:{ int cont = 0;
      	       long inicTime = System.nanoTime(); 
               for (int i=0; i<nIter; i++)cont++;
                 System.out.println("Tiempo sin Bloqueos: "+(System.nanoTime()-inicTime));
               };break;
      case 1:{ int otrocont = 0;
      	       long inicTime = System.nanoTime(); 
               for (int i=0; i<nIter; i++)synchronized(this){otrocont++;}
                 System.out.println("Tiempo con Bloqueos: "+(System.nanoTime()-inicTime));
               };break;
    }//switch
  }
  public static void main(String[]args){
    Scanner s = new Scanner(System.in);
    nIter = s.nextInt();
    new retardoMutex(0).start();
    new retardoMutex(1).start();
  }
}
