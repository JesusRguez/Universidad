/**
 * @(#)Critica.java
 * @author
 * @version 1.00 2012/10/25
 */


public class Critica
{
	private int n=0;
    public Critica() {}
    public void inc(){n++;}
    public void dec(){n--;}
    public int vDato(){return(n);}


}