public class cenaFilosofos{
  private int[] cucharas;
  private int   nFilo = 5;
  
  public cenaFilosofos(){
    cucharas = new int[nFilo];
    for(int i=0; i<cucharas.length; i++)
      cucharas[i]=2;
  }
  
  public synchronized void cogerCucharas(int i){
    while((cucharas[i]!=2)) try{wait();}catch(Exception e) {};
    cucharas[(i+1)%nFilo]--;
    if(i==0)cucharas[nFilo-1]--;
    else cucharas[(i-1)%nFilo]--;
  }
  
  public synchronized void dejarCucharas(int i){
    cucharas[(i+1)%nFilo]++;
    if(i==0)cucharas[nFilo-1]++;
    else cucharas[(i-1)%nFilo]++;
    notifyAll();
    //cual es el por que de esta diferencia respecto al modelo teorico?
  }
}
