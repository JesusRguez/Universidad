 /**Ejemplo de Monitor sencillo para productor-consumidor. 
 *Encapsula un buffer protegida por la abstraccion
 *y posee una interfaz de dos metodos para insertar y extraer, y se provee
 *la sincronizaci�n necesaria. 
 */
 
    public class BufferSeguro {        
      private int numRanuras = 0;
      private double[] buffer = null;
      private int InPtr = 0, OutPtr = 0;
      private int cont = 0;
      
      public BufferSeguro(int numSlots) {
        this.numRanuras = numRanuras;
        buffer = new double[numRanuras];
      }
      
      public synchronized void insertar (double valor) {
            	      
        while((cont == numRanuras))
          try {
            wait();
          } catch (InterruptedException e) {
            System.err.println("wait interrumpido");
          }
        buffer[InPtr] = valor;
        InPtr = (InPtr + 1) % numRanuras;  
        cont++;                   
        notifyAll();  
      }
      
      public synchronized double extraer () {
      	     
        double valor;
        while(cont == 0)
          try {
            wait();
          } catch (InterruptedException e) {
            System.err.println("wait interrumpido");
          }
        valor = buffer[OutPtr];
        OutPtr = (OutPtr + 1) % numRanuras;
        cont--;                           
        notifyAll(); 
        return valor;
      }
    }
    







