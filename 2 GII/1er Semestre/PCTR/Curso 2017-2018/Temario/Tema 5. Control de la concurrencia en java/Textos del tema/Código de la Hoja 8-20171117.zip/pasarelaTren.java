public class pasarelaTren{
  public static synchronized void cruzarPasarela(){}
  public static void main(String[] args){
    Thread p = new Thread (
    	           new Runnable(){
    	           	   public void run(){
    	           	  for(;;)cruzarPasarela();}});
    Thread q = new Thread (
    	           new Runnable(){
    	           	   public void run(){
    	           	  for(;;)cruzarPasarela();}});
    p.start();
    q.start();
  }	  
}
