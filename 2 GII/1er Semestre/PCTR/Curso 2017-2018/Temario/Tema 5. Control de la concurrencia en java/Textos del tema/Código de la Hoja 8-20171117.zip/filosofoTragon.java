import java.util.concurrent.*;

public class filosofoTragon
  implements Runnable{
  private static int contFil = 0;
  private        int numFil;
  private static Object lock = new Object();
  private cenaFilosofos mesaComun;
  
  
  public filosofoTragon(cenaFilosofos m){
    mesaComun = m;
    synchronized(lock){
      numFil=contFil;
      contFil++;
    }
  }
  
  public void run(){
    Thread j = Thread.currentThread(); 	  
    for(;;){
      System.out.println("Filosofo "+this.numFil+" meditando...");
      mesaComun.cogerCucharas(this.numFil);
      System.out.println("Filosofo "+this.numFil+" comiendo...");
      mesaComun.dejarCucharas(this.numFil);
      try{j.sleep(100);}catch(InterruptedException e){}
    }
  }
  
  public static void main(String[] args){
    int nFil=5;	
    cenaFilosofos   mesa = new cenaFilosofos();
    for(int i=0; i<=nFil-1; i++)
      new Thread(new filosofoTragon(mesa)).start();
  }
}  
