
/**
 * @author Jesús Rodríguez Heras
 */
public class Paciente {

    //Atributos de la clase Paciente
    String nombre, dni, direccion, telefono, compañiaSeguros, diagnostico, sexo;
    int edad, NSS;
}
