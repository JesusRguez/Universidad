#include <iostream>
#include <ostream>
#include "alg_grafoMA.h"
#include "alg_grafoPMC.h"
#include "alg_grafo_E-S.h"
#include "colaenla.h"
#include "grafoMA.h"
#include "grafoPMC.h"
#include "listaenla.h"
#include "matriz.h"
#include "pilaenla.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}

/*EJERCICIO 2*/
template <typename tCoste>
int diametro(const GrafoP<tCoste>& G)
{


}

template <typename tCoste>
matriz<tCoste> pseudocentro (const GrafoP<tCoste>& G, matriz<typename GrafoP<tCoste>::vertice>& M) //MODIFICA LA MATRIZ
{
    matriz<tCoste> P;
    P = Floyd(G,M);
    int posmin,i;

    int tope = P.dimension();


    int vecmax1[tope],vecmax2[tope];
    vecmax1 = maxivec(P,tope);
    vecmax2 = maxivec(P,tope);
    int aux[tope];
    for(i=0;i<tope;i++)
        aux[i] = vecmax1[i] + vecmax2[i];



    return posmin = minimoV(aux,tope);
}

template <typename tCoste>
int maxivec ( matriz<typename GrafoP<tCoste>::vertice>& P, int tope) // DADO UNA MATRIZ BUSCA EL MAXIMO DE CADA COLUMNA, EL MAXIMO LO PONE A 0
{ //DEVUELVE UN VECTOR CON EL VERTICES MAS ALEJADO A UN NODO
    int v[tope];
    int x,y,maximo;
    for (x=0; x<tope; x++)
    {
        maximo = P[x][0];
        for(y=1; y<tope; y++)
        {
            if(P[x][y]>maximo)
                maximo=P[x][y];
        }
        v[x] = maximo;
        P[x][y]=0; // PARA NO VOLVER A SELECCIONAR EL MAXIMO
    }
    return v;
}

int minimoV( int *v, int tope) // DADO UN VECTOR Y SU TAMA�O LO RECORRO Y DEVUELVO LA POSICION DEL MINIMO VALOR
{
    int mini = v[0];
    int posmin = 0;
    int i;
    for (i=1;i<tope;i++)
    {
        if (v[i]<mini)
        {
            mini = v[i];
            posmin = i;
        }
    }
    return posmin;
}





