#include <iostream>

#include "alg_grafo_E-S.h"
#include "laberinto_paredes.hpp"


int main(){

    typedef GrafoP<unsigned>::vertice vertice;
    typedef GrafoP<unsigned>::tCamino tCamino;

    size_t N = 3; //laberinto de 3x3
    vector<vertice> P;
    tCamino ruta;

    vector<pared> paredes
    {
        {{0, 0}, {1, 0}},
            {{0, 1}, {1, 1}},
                {{1, 1}, {1, 2}},
                    {{2, 0}, {2, 1}}
    };

    ruta = laberinto_paredes<unsigned>
        (N, paredes, casilla{0, 2}, casilla{2, 0});

    tCamino::posicion p;

    cout << "----------------------" << endl;
    cout << "El camino a seguir es:" << endl;
    cout << "----------------------" << endl;
    cout << "NODO\tCASILLA" << endl;

    p = ruta.primera();

    while(p != ruta.fin()){
        cout << ruta.elemento(p) << "\t("
             << nodoToCasilla(ruta.elemento(p), N).fila << ", "
             << nodoToCasilla(ruta.elemento(p), N).col << ")" << endl;
        p = ruta.siguiente(p);
    }
}
