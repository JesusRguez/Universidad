#ifndef TADARBOLBINARIOBUSQUEDA_H_INCLUDED
#define TADARBOLBINARIOBUSQUEDA_H_INCLUDED

#include <cassert>
template <typename T> class Abb {
public:
Abb();
// constructor
const Abb& buscar(const T& e) const;
void insertar(const T& e);
void eliminar(const T& e);
bool vacio() const;
const T& elemento() const;
const Abb& izqdo() const;
const Abb& drcho() const;
Abb(const Abb& A);
// ctor. de copia
Abb& operator =(const Abb& A);
// asig. �rboles
~Abb();
void DestSubarbol();
private:
struct arbol {
T elto;
Abb izq, der;
arbol(const T& e): elto(e) {}
};
arbol* r;
// ra�z del �rbol
T borrarMin();
void copiar(const Abb& A);
};



template <typename T>
inline Abb<T>::Abb() : r(0) {}
template <typename T>
inline bool Abb<T>::vacio() const
{
return r == 0;
}

template <typename T>
const Abb<T>& Abb<T>::buscar(const T& e) const
{
if (r == 0)
// �rbol vac�o, e no encontrado
return *this;
else if (e < r->elto)
// buscar en sub�rbol izqdo.
return r->izq.buscar(e);
else if (r->elto < e)
// buscar en sub�rbol drcho.
return r->der.buscar(e);
else
// encontrado e en la ra�z
return *this;
}

template <typename T>
void Abb<T>::eliminar(const T& e)
{
if (r != 0) {
// �rbol no vac�o
if (e < r->elto)
// quitar e del sub�rbol izqdo.
r->izq.eliminar(e);
else if (r->elto < e)
// quitar e del sub�rbol drcho.
r->der.eliminar(e);
else
// quitar e de la ra�z
if (r->izq.r == 0 && r->der.r == 0) {
// 1. Ra�z es hoja
delete(r);
r = 0;
// el �rbol queda vac�o
}
else if (r->der.r == 0) {
// 2. Ra�z s�lo tiene hijo izqdo.
arbol* a = r->izq.r;
r->izq.r = 0;
// impide destruir el sub�rbol izqdo.
delete(r);
r = a;
}
else if (r->izq.r == 0) {
// 3. Ra�z s�lo tiene hijo drcho.
arbol* a = r->der.r;
r->der.r = 0;
// impide destruir el sub�rbol drcho.
delete(r);
r = a;
}
else
// 4. Ra�z tiene dos hijos
// Eliminar el m�nimo del sub�rbol derecho y sustit
uir
// el elemento de la ra�z por �ste.
r->elto = r->der.borrarMin();
}
}
// M�todo privado
template <typename T>
T Abb<T>::borrarMin()
// Elimina el nodo que almacena el menor elemento
// del �rbol. Devuelve el elemento del nodo eliminado.
{
if (r->izq.r == 0) {
// sub�rbol izquierdo vac�o
T e = r->elto;
arbol* hd = r->der.r;
r->der.r = 0;
// impide destruir el sub�rbol drcho.
delete(r);
r = hd;
// sustituir r por el sub�rbol drcho.
return e;
}
else
return r->izq.borrarMin();
}
template <typename T>
inline const T& Abb<T>::elemento() const
{
assert(r != 0);
return r->elto;
}
template <typename T>
inline const Abb<T>& Abb<T>::izqdo() const
{
assert(r != 0);
return r->izq;
}
template <typename T>
inline const Abb<T>& Abb<T>::drcho() const
{
assert(r != 0);
return r->der;
}
template <typename T>
inline Abb<T>::Abb(const Abb<T>& A): r(0)
{
copiar(A);
}
template <typename T>
Abb<T>& Abb<T>::operator =(const Abb<T>& A)
{
if (this != &A) {
// evitar autoasignaci�n
this->~Abb();
// vaciar el �rbol
copiar(A);
}
return *this;
template <typename T>
Abb<T>::~Abb()
{
if (r != 0) {
// �rbol no vac�o
delete r;
// llama a r->izq.~Abb() y a r->der.~Abb()
r = 0;
// el �rbol queda vac�o
}
}
// M�todo privado
template <typename T>
void Abb<T>::copiar(const Abb<T>& A)
// Copia el �rbol a en *this
{
if (A.r != 0) {
// �rbol no vac�o
r = new arbol(A.r->elto);
// copiar ra�z
r->izq.copiar(A.r->izq);
// copiar sub�rbol izqdo.
r->der.copiar(A.r->der);
// copiar sub�rbol drcho.
}
}

template <typename T>
void DestSubarbol(const T& e)
{
if (r != 0){
    else if (e < r->elto)

    r->izq.DestSubarbol(e);
    else if (r->elto < e)

    r->der.DestSubarbol(e);
    else
     delete r;
}
}
#endif // TADARBOLBINARIOBUSQUEDA_H_INCLUDED
